﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.txtP = New System.Windows.Forms.TextBox()
        Me.txtUN = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtS = New System.Windows.Forms.TextBox()
        Me.txtM = New System.Windows.Forms.TextBox()
        Me.txtE = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'txtP
        '
        Me.txtP.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtP.Location = New System.Drawing.Point(334, 119)
        Me.txtP.Name = "txtP"
        Me.txtP.Size = New System.Drawing.Size(254, 50)
        Me.txtP.TabIndex = 8
        '
        'txtUN
        '
        Me.txtUN.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUN.Location = New System.Drawing.Point(332, 48)
        Me.txtUN.Name = "txtUN"
        Me.txtUN.Size = New System.Drawing.Size(254, 50)
        Me.txtUN.TabIndex = 7
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(117, 119)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(160, 45)
        Me.Label3.TabIndex = 6
        Me.Label3.Text = "Password:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(92, 48)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(185, 45)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "User Name:"
        '
        'txtS
        '
        Me.txtS.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtS.Location = New System.Drawing.Point(332, 348)
        Me.txtS.Name = "txtS"
        Me.txtS.Size = New System.Drawing.Size(253, 50)
        Me.txtS.TabIndex = 18
        '
        'txtM
        '
        Me.txtM.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtM.Location = New System.Drawing.Point(333, 272)
        Me.txtM.Name = "txtM"
        Me.txtM.Size = New System.Drawing.Size(253, 50)
        Me.txtM.TabIndex = 17
        '
        'txtE
        '
        Me.txtE.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtE.Location = New System.Drawing.Point(333, 194)
        Me.txtE.Name = "txtE"
        Me.txtE.Size = New System.Drawing.Size(253, 50)
        Me.txtE.TabIndex = 16
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(49, 351)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(228, 45)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Science Grade:"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(84, 275)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(195, 45)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Math Grade:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(57, 194)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(222, 45)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "English Grade:"
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!)
        Me.Button2.Location = New System.Drawing.Point(333, 448)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(182, 103)
        Me.Button2.TabIndex = 20
        Me.Button2.Text = "Cancel"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Yu Gothic UI", 16.0!)
        Me.Button1.Location = New System.Drawing.Point(145, 448)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(182, 103)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "Confirm"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(652, 595)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.txtS)
        Me.Controls.Add(Me.txtM)
        Me.Controls.Add(Me.txtE)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.txtP)
        Me.Controls.Add(Me.txtUN)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Name = "Form3"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Form3"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents txtP As TextBox
    Friend WithEvents txtUN As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents txtS As TextBox
    Friend WithEvents txtM As TextBox
    Friend WithEvents txtE As TextBox
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
End Class
